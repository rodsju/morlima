<?php
/** 
 * As configurações básicas do WordPress.
 *
 * Esse arquivo contém as seguintes configurações: configurações de MySQL, Prefixo de Tabelas,
 * Chaves secretas, Idioma do WordPress, e ABSPATH. Você pode encontrar mais informações
 * visitando {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. Você pode obter as configurações de MySQL de seu servidor de hospedagem.
 *
 * Esse arquivo é usado pelo script ed criação wp-config.php durante a
 * instalação. Você não precisa usar o site, você pode apenas salvar esse arquivo
 * como "wp-config.php" e preencher os valores.
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar essas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define('DB_NAME', 'bd_morlima');

/** Usuário do banco de dados MySQL */
define('DB_USER', 'root');

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', '11qqaa');

/** nome do host do MySQL */
define('DB_HOST', 'localhost');

/** Conjunto de caracteres do banco de dados a ser usado na criação das tabelas. */
define('DB_CHARSET', 'utf8');

/** O tipo de collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * Você pode alterá-las a qualquer momento para desvalidar quaisquer cookies existentes. Isto irá forçar todos os usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'O~&c@3jdBg6O D]&PFKj/:XrvlbIN:<Z?szzlk$V>0DSi+F3267}_2/AxcGd 8[]');
define('SECURE_AUTH_KEY',  '/DNK(h972gB1|Ur<ae2G+<LDnn-*vEvMgS-[$k7{|]#5Z%}U(yI(88>lD.L-7noz');
define('LOGGED_IN_KEY',    'c|~Y-&4mqjgOw?|WoY%Ky(WkMy-_}o{C[;[kIGwpCH(hh$|qPM+b*<,$>rCgsoS}');
define('NONCE_KEY',        '> !ZXp{CtV4Xqq4m5S@yce:wZ?:8/-CiP(Z6 +o<^H?ux4V)Z-p(}/h96omUPVdk');
define('AUTH_SALT',        'X 200]4Z l-/-Ws/joY${OVz0)sU^l#c.w&0*!2X?JGvX&D6L}ggt]9xVL2MRhF[');
define('SECURE_AUTH_SALT', 'Soo2_KE+|t}Laj{_iTtOCSLU`L~Glkows:>0/4SXh>~Wv|-lMR%Qq8D[--w//F<z');
define('LOGGED_IN_SALT',   'yJcU#2468uE0|-8~5(5oSM]-(A1Mk9lolNE5uq)@0+*gQOS@_&1CD.CV>F!E-T(M');
define('NONCE_SALT',       'Uya#oDp4u^j-GXL(5r$ S%r2@MmEckS&Zy,lu.)-2exH8x]?q8.LMOXVzaAP~/)A');

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der para cada um um único
 * prefixo. Somente números, letras e sublinhados!
 */
$table_prefix  = 'wp_';

/**
 * O idioma localizado do WordPress é o inglês por padrão.
 *
 * Altere esta definição para localizar o WordPress. Um arquivo MO correspondente ao
 * idioma escolhido deve ser instalado em wp-content/languages. Por exemplo, instale
 * pt_BR.mo em wp-content/languages e altere WPLANG para 'pt_BR' para habilitar o suporte
 * ao português do Brasil.
 */
define('WPLANG', 'pt_BR');

/**
 * Para desenvolvedores: Modo debugging WordPress.
 *
 * altere isto para true para ativar a exibição de avisos durante o desenvolvimento.
 * é altamente recomendável que os desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis do WordPress e arquivos inclusos. */
require_once(ABSPATH . 'wp-settings.php');
